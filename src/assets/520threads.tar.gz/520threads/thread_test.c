#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>

pthread_t tid[10000];


void* doSomeTest(void *arg)
{
    char *p;
    unsigned long i = 0;
    pthread_t id = pthread_self();
    
    p = malloc(120);
    if(!p) {
        printf("malloc %s\n", strerror(errno));
        return;
    }

    //printf("%d waitting!\n", id);

    while(1);

    free(p);
    return NULL;
}

void print_usage(void)
{
    printf("./pthreadtest thread_number\n");
    printf("./pthreadtest 520\n");
    exit(-1);
}

int thread_number = 1;
int main(int argc, char *argv[])
{
    int i = 0;
    int err;
    void *status;

    if(argc != 2) {
        print_usage();
    }
    thread_number = atoi(argv[1]);

    printf("main pid: %d, thread number: %d\n", getpid(), thread_number);

    while(i < thread_number) {
        err = pthread_create(&(tid[i]), NULL, &doSomeTest, NULL);
        if (err != 0)
            printf("\ncan't create thread :[%s]", strerror(err));
        else {
        //    printf("\n Thread %d created success\n", i);
        }

        i++;
    }

    printf("waiting %d threads to complete!\n", thread_number);
    for(i=0; i<thread_number; i++) {
        pthread_join(tid[i], &status);
    }

    printf("end of the pthread test!\n");
    return 0;
}
