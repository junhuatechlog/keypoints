#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>

pthread_t tid[2];

volatile int hsfn = 0;

void doWrite(void *arg)
{
    while(1) {
        printf("update: hsfn: %d\n", hsfn);
        hsfn ++ ;
        printf("update: hsfn: %d\n", hsfn);
        if(hsfn > (2<<20 -1)) {
            hsfn = 0;
        }
        usleep(100000);
    }
}

void doRead(void *arg)
{
    while(1) {
        printf("hsfn: %d\n", hsfn);
        usleep(100000);
    }
}

void * doLoop(void *arg) {
    pthread_t id = pthread_self();
    if(pthread_equal(id,tid[0])) {
        doWrite(arg);
    }

    if(pthread_equal(id,tid[1])) {
        doRead(arg);
    }
}

void print_usage(void)
{
    printf("./pthreadtest n");
    printf("if illegal value will be read when there is no lock updating the global value!\n");
    exit(-1);
}

int thread_number = 2;
int main(int argc, char *argv[])
{
    int i = 0;
    int err;
    void *status;

    printf("main pid: %d, thread number: %d\n", getpid(), thread_number);

    while(i < thread_number) {
        err = pthread_create(&(tid[i]), NULL, &doLoop, NULL);
        if (err != 0)
            printf("\ncan't create thread :[%s]", strerror(err));
        else {
            printf("\n Thread %d created success\n", i);
        }

        i++;
    }

    printf("waiting %d threads to complete!\n", thread_number);
    for(i=0; i<thread_number; i++) {
        pthread_join(tid[i], &status);
    }

    printf("end of the pthread test!\n");
    return 0;
}
