#!/bin/bash
while true
do
let num=$num+1
./socket_test 3
ret_value=$?
rmmod xfrm_user
rmmod xfrm_algo
if [ $ret_value -eq 0 ]
then
echo test ok $num
else
echo !!!test failed number: $num, ret:$ret_value
exit 1
fi
done

