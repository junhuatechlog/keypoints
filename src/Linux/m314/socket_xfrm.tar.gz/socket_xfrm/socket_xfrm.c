#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>          
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/syscall.h>
#include <syslog.h>
#define getpid()        syscall(__NR_getpid)
#define MAX_THREADS 100

int thread_ret = 0;

void* test_socket(void *arg)
{
    int fd = 0;
    fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_XFRM);
    if(fd < 0)
    {
        syslog(LOG_INFO,"######thread:%d create socket failed, return value: %d,errno:%d[%s]\n", 
                                                                pthread_self(),fd, errno,strerror(errno));
    } 
    else
    {
    	syslog(LOG_INFO,"@@@@@@thread:%d create socket OK, return value: %d\n", pthread_self(),fd);
    }

    if(fd > 0) 
    {
        close(fd);
    }
    else
    {
        thread_ret = getpid();
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    int i = 0;
    int ret = 0;
    void *status;
    pthread_attr_t attr;
    unsigned int thread_nums = 1;    
    char name[128] = {0};
    pthread_t pid[MAX_THREADS];

    if(argc != 2) {
        printf("%s threadnumbers\n", argv[0]);
        return 0;    
    }

    thread_nums = atoi(argv[1]);

    if(thread_nums > MAX_THREADS) thread_nums = MAX_THREADS;

    printf("Create thread numbers: %d\n", thread_nums);
    syslog(LOG_INFO,"Create thread numbers: %d\n",thread_nums);

    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 1024*128);

    for(i = 0; i < thread_nums; i++){
        ret = pthread_create(&pid[i], NULL, test_socket, NULL);
        if (ret != 0)
            printf("Create thread failed\n");
        else {
            sprintf(name,"tsocket_%d",i);
            pthread_setname_np(pid[i],name);	
        }
    }

    for(i=0; i<thread_nums; i++) {
        pthread_join(pid[i], &status);
    }

    if(thread_ret == 0)
    {
        syslog(LOG_INFO,"create all socket success");
    }
    else 
    {
        syslog(LOG_INFO,"!!!!!!create socket failured, thread_id:%d",thread_ret);
        thread_ret = 88;
    }
    
    return thread_ret;
}
